<?php
class db {
	
	public $insertSQL;
	public $insertID;
	public $selectSQL;
	
	public function insert() {

		include("../connections/conn.php");
		
		mysql_select_db($database_ndb, $ndb);
		$query_rs = $this->insertSQL;
		$rs = mysql_query($query_rs, $ndb) or die(mysql_error());
		$this->insertID = mysql_insert_id();
		//echo $query_rs;
		
	}
		
	public function select() {

		include("../connections/conn.php");
		
		mysql_select_db($database_ndb, $ndb);
		$query_rs = $this->selectSQL;
		$rs = mysql_query($query_rs, $ndb) or die(mysql_error());
		echo '<div id="results" style="margin-left:50px;height:120px;overflow:auto;"> ';
		while ($row = mysql_fetch_assoc($rs)){
			echo $row['item_num']." ".$row['track_num'].": ".$row['title_of_chant']." ".$row['page']." [".$row['time']."] ".$row['comments']." <a href='#' onclick='deleteTrack(".$row['id'].", \"".$row['title_of_chant']."\")' style='color:red'>X</a><br>";
		}
		echo "</div>";
	}
	
	public function selectRecord() {

		include("../connections/conn.php");
		
		mysql_select_db($database_ndb, $ndb);
		$query_rs = $this->selectSQL;
		$rs = mysql_query($query_rs, $ndb) or die(mysql_error());
		echo "<blockquote>";
		while ($row = mysql_fetch_assoc($rs)){
			echo '<label>Serial Number:
</label>
<input name="serial_num" type="text" id="serial_num" tabindex="1" size="9" maxlength="9"  value="'.$row["serial_num"].'"/>
<br />
<label>Format Code:</label>
<input name="record_id" type="hidden" id="record_id" value="'.$row["id"].'"/>
<input name="format_code" type="text" id="format_code" tabindex="2" size="2" maxlength="2" value="'.$row["format_code"].'"/>
<br />
<label>Country Code:</label>
 <input id="country_code" type="text" tabindex="3" size="2" maxlength="2" value="'.$row["country_code"].'"/>
<br />
<label>Label Name:</label>
<input id="label_name" type="text" tabindex="4" size="30" maxlength="55" value="'.$row["label_name"].'"/>
<br />
<label>Prefix to Number:</label>
<input id="prefix_to_num" type="text" tabindex="5" size="15" maxlength="15" value="'.$row["prefix_to_number"].'"/>
<br />
<label>Issue Number:</label>
<input id="issue_num" type="text" tabindex="6" size="15" maxlength="15" value="'.$row["issue_number"].'"/>
<br />
<label>Suffix:</label>
<input id="suffix" type="text" tabindex="6" size="9" maxlength="9" value="'.$row["suffix"].'"/>
<br />
<label>Record Title:</label>
<input id="record_title" type="text" tabindex="7" size="30" maxlength="75" value="'.$row["record_title"].'"/>
<br />
<label>Alternate Numbers:</label>
<input id="alt_num" type="text" tabindex="8" size="30" maxlength="255" value="'.$row["alternate_num"].'"/>
<br />
<label>Performers:</label>
<input id="performers" type="text" tabindex="9" size="30" maxlength="75" value="'.$row["performers"].'"/>
<br />
<label>Director:</label>
<input id="director" type="text" tabindex="10" size="30" maxlength="75" value="'.$row["director"].'"/>
<br />
<label>Solo:</label>
<input id="solo" type="text" tabindex="11" size="30" maxlength="75" value="'.$row["solo"].'"/>
<br />
<label>Date:</label>
<input id="date" type="text" tabindex="12" size="30" maxlength="50" value="'.$row["date_of_recording"].'"/>
<br />
<label>Keywords:</label>
<input id="keywords" type="text" tabindex="15" size="55" maxlength="250" value="'.$row["keywords"].'"/>
<br />
<label>Comments:</label>
<textarea cols="30" rows="5" id="comments" tabindex="13">'.$row["comments"].'</textarea>';
			
			
		//	$row['label_name']." ".$row['record_title'].": ".$row['format_code']." (".$row['country_code']."), ".
			//$row['prefix_to_number']." ".$row['issue_number'].$row['alternate_num']." [".$row['performers']."]<br>";
		}
		echo "</blockquote>";
	}
}


?>
