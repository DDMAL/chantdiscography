<?php
include_once('../classes/class.record.php');
include_once('../classes/class.db.php');

$fc = $_POST['fc'];
$fc_update = $_POST['fc_update'];
$serial_num = (int)$_POST['serial_num'];
$cc = $_POST['cc'];
$label = $_POST['label'];
$prefix = $_POST['prefix'];
$suffix = $_POST['suffix'];
$issue = $_POST['issue'];
$title = $_POST['title'];
$alt_num = $_POST['alt_num'];
$performers = $_POST['performers'];
$director = $_POST['director'];
$solo = $_POST['solo'];
$date = $_POST['date'];
$comments = $_POST['comments'];
$record_id = $_POST['record_id'];
$update = $_POST['update'];
$keywords = $_POST['keywords'];
//$upName = $_POST['upName'];
//$ts2 = $_POST['ts2'];


if ( $fc == true) {
$insertDB = new db;
$insertDB->insertSQL = "INSERT INTO record VALUES ('', $serial_num, '$fc', '$cc', '$label', '$prefix', '$issue', '$suffix', '$title', '$alt_num', '$performers', '$director', '$solo', '$date', '$comments', '$keywords')";
//echo $insertDB->insertSQL;
$insertDB->insert();
$id = $insertDB->insertID;

$newRecord = new record;
$newRecord->fc = $fc;
$newRecord->cc = $cc;
$newRecord->prefix = $prefix;
$newRecord->suffix = $suffix;
$newRecord->issue = $issue;
$newRecord->title = $title;
$newRecord->alt_num = $alt_num;
$newRecord->performers = $performers;
$newRecord->director = $director;
$newRecord->solo = $solo;
$newRecord->date = $date;
$newRecord->comments = $comments;
$newRecord->keywords = $keywords;
$newRecord->label = $label;
$newRecord->insertID = $id;

echo $newRecord->showTracks();
$insertDB->selectSQL = "Select id, item_num, track_num, title_of_chant, page, time, comments from chant where record_id =".$id." ORDER BY item_num";
$insertDB->select();
echo $newRecord->showRecord();
}


if ( $update == true) {
$updateDB = new db;
$updateDB->selectSQL = "select id, serial_num, format_code, country_code, label_name, prefix_to_number, issue_number, suffix, record_title,
	alternate_num, performers, director, solo, date_of_recording, keywords, comments 
 	from record where id=".$update;
$updateDB->selectRecord();
}

if($fc_update == true){


	
$updateDB = new db;
$updateDB->insertSQL = "UPDATE record SET serial_num = $serial_num, format_code = '$fc_update', country_code ='$cc', label_name='$label', 
	prefix_to_number='$prefix', issue_number='$issue', suffix='$suffix', record_title='$title', alternate_num='$alt_num', performers='$performers', director='$director', solo='$solo', keywords='$keywords',
	date_of_recording='$date', comments='".addslashes($comments)."'  
	WHERE id = '$record_id'";
$updateDB->insert();
echo "<font color='red'> Record updated</font><br>";
$newRecord = new record;
$newRecord->fc = $fc_update;
$newRecord->cc = $cc;
$newRecord->prefix = $prefix;
$newRecord->issue = $issue;
$newRecord->suffix = $suffix;
$newRecord->title = $title;
$newRecord->alt_num = $alt_num;
$newRecord->performers = $performers;
$newRecord->director = $director;
$newRecord->solo = $solo;
$newRecord->date = $date;
$newRecord->keywords = $keywords;
$newRecord->comments = $comments;
$newRecord->label = $label;
$newRecord->insertID = $record_id;
echo $newRecord->showTracks();
$updateDB->selectSQL = "Select id, item_num, track_num, title_of_chant, page, time, comments from chant where record_id =".$record_id." ORDER BY item_num";
$updateDB->select();
echo $newRecord->showRecord();
}
//echo "nothing";
?>
